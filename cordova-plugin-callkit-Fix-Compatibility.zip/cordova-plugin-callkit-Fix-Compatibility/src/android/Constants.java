
package com.dmarc.cordovacall;

public class Constants {

    public static final String PREFERENCES_FILE_NAME = "UserPreferencesPluginPref";
    public static final String CALL_ANSWERED_BY_USER = "CallAnsweredByUser";
    public static final String MEETING_NUMBER = "MeetingNumber";
    public static final String MEETING_PASSWORD = "MeetingPassword";
    public static final String DISPLAY_NAME = "DisplayName";
}
